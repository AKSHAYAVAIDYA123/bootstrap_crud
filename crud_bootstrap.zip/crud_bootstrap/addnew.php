<?php
	include('conn.php');
	
	$firstname=$_POST['firstname'];
	$lastname=$_POST['lastname'];
	$address=$_POST['address'];
	$date=$_POST['date'];
	
	mysqli_query($conn,"insert into user (firstname, lastname, address,date) values ('$firstname', '$lastname', '$address', '$date')");
	header('location:index.php');

?>